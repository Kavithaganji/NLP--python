# Hands-On-Natural-Language-Processing-with-Python

This repository is for my students of Udemy. You can find all lecture codes along with mentioned files for reading in here. 
So, feel free to clone it and if you have any problem just raise a question.

For cloning you must have "Git" installed in your system.

To clone just type the following:

git clone https://github.com/bijoyandas/Hands-On-Natural-Language-Processing-with-Python.git

If you find any mistakes or you can't figure out something, raise a question. I will get back to you asap.
