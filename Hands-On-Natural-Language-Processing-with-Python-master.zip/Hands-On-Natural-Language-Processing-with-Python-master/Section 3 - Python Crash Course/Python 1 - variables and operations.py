# Introduction to Python

# Printing to he console

print("Hello world")

a = 10
b = "This is a string"
c = 12.5

print(a,b,c)

print("The value of a is ",a)


# Mathematical Operations

num1 = 12
num2 = 4

result = num1+num2
result = num1-num2
result = num1*num2
result = num1/num2
result = num1%num2

print(result)


# Special operations

sen = "I love Avengers\n"
print(sen*5)

print("I like cats", end=" ")
print("so much")